/* script.js 
   Author:
   Date:
*/


$(document).ready(function(){ // begin document.ready block

	// BUILD A GALLERY WITH POPUPS

// part one

$('.detail').hide();

	var leng = classmates.length;

	for (var i=0; i<leng; i++) {
		$(".object").append('<div class = "name">'
			 + '<img src = "img/emoji/emoji-' + classmates[i].gradID + '.jpg">'
			 + '<div class = caption>' + classmates[i].firstname + '&nbsp' + classmates[i].lastname+ '</div>'
			 + '</div>');		
	}
		

	$(".name").click(function(){

		$('.detail').show();
	});




	for (var i=0; i<leng; i++) {
			$(".detailcon").append('<div class = pic>'+ '<img src = "img/emoji/emoji-' + classmates[i].gradID + '.jpg">'+ '</div>');}
		
	for (var i=0; i<leng; i++) {
			$(".detailcon").append('<div class = more>'
				+ '<div class = "fullname">'+ classmates[i].firstname + '&nbsp' + classmates[i].lastname+ '</div>'
				+ '<div class = "hometown">'+ 'Hometown: '+ classmates[i].hometown+ '</div>'
				+ '<div class = "zodiac">'+ 'Zodiac sign: ' + classmates[i].zodiac+ '</div>'
				+ '<div class = "favcolor">'+'Favorite color: ' + classmates[i].favcolor+ '</div>'
				+ '<div class = "favcity">'+ 'Favorite city: ' + classmates[i].favcity+ '</div>'
				+ '</div>');}
// function myFunction() {
//   document.getElementById("myDIV").style.display = "none";
// }

	$(".closebtn").click(function(){
		$('.detail').hide();
	});
 //end document.ready block

}); 